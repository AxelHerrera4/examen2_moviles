package com.example.menus_contextuales

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
